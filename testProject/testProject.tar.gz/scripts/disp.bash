#!/bin/bash

COUNTER=0
while [  $COUNTER -lt 10 ]; do
   ls
   clear
   cat results
   sleep 6
done;
